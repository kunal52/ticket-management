package com.ticket.management.app;

import com.ticket.management.app.entity.Ticket;
import com.ticket.management.app.service.TicketBookingService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.util.Date;

@SpringBootApplication
public class TicketManagementAppApplication {

	public static void main(String[] args)
	{
		SpringApplication.run(TicketManagementAppApplication.class,args);
	}
}

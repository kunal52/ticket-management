package com.ticket.management.app.controller;

import com.ticket.management.app.entity.Ticket;
import com.ticket.management.app.service.TicketBookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/tickets")  //by default get mapping h
public class TicketManagementController {

    @Autowired
    private TicketBookingService ticketBookingService;

    @PostMapping(value = "/create") //we have to save obj postmapping hoga
    public Ticket createTicket(@RequestBody Ticket ticket) {
        return ticketBookingService.createTicket(ticket);
    }

    @GetMapping(value = "/ticket/{ticketId}")
    public Ticket getTicketById(@PathVariable("ticketId") Integer ticketId) {
        return ticketBookingService.getTicketById(ticketId);
    }

    @GetMapping(value = "/alltickets")
    public List<Ticket> getAllTicket() {
        return ticketBookingService.getAllTicket();
    }

    @PutMapping(value = "/update/{ticketId}/{newEmail}")
    public Ticket updateTicket(@PathVariable("ticketId") Integer ticketId, @PathVariable("newEmail") String newEmail)
    {
        return ticketBookingService.updateTicket(ticketId, newEmail);
    }

    @DeleteMapping(value = "/deleteTicket/{ticketId}")
    public ResponseEntity<?> deleteTicket(@PathVariable("ticketId") Integer ticketId) {
        ticketBookingService.deleteTicket(ticketId);
         return ResponseEntity.accepted().build();
    }
}

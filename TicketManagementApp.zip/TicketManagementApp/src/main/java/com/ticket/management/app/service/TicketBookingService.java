package com.ticket.management.app.service;

import com.ticket.management.app.entity.Ticket;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;


public interface TicketBookingService {

    ResponseEntity<Ticket> createTicket(Ticket ticket);

    ResponseEntity<Ticket> getTicketById(Integer ticketId);

    ResponseEntity<List<Ticket>> getAllTicket();

    ResponseEntity<Ticket> deleteTicket(Integer ticketId);

    ResponseEntity<Ticket> updateTicket(Integer ticketId, String newEmail);
}

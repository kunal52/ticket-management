package com.ticket.management.app.service;

import com.ticket.management.app.dao.TicketBookingDao;
import com.ticket.management.app.entity.Ticket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TicketBookingServiceImpl implements TicketBookingService {

    @Autowired
    private TicketBookingDao ticketBookingDao;

    @Override
    public ResponseEntity<Ticket> createTicket(Ticket ticket) {
        return ResponseEntity.ok(ticketBookingDao.save(ticket));
    }

    @Override
    public ResponseEntity<Ticket> getTicketById(Integer ticketId) {
        return ResponseEntity.ok(ticketBookingDao.findById(ticketId).orElse(null));
    }

    @Override
    public ResponseEntity<List<Ticket>> getAllTicket() {
        return ResponseEntity.ok(ticketBookingDao.findAll());
    }

    @Override
    public ResponseEntity<Ticket> deleteTicket(Integer ticketId) {
        ticketBookingDao.deleteById(ticketId);
         return ResponseEntity.ok().build();
    }

    @Override
    public ResponseEntity<Ticket> updateTicket(Integer ticketId, String newEmail) {
        Optional<Ticket> ticketFromDb = ticketBookingDao.findById(ticketId);
        if (!ticketFromDb.isPresent())
            return null;
        Ticket ticket = ticketFromDb.get();
        ticket.setEmail(newEmail);
        return ResponseEntity.ok(ticketBookingDao.save(ticket));
    }

}
